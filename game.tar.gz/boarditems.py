from bard import *
from player import *
from donkey import *
from ball import *
class boarditems:
	def __init__(self,x,y):
		self.x=x
		self.y=y
		self.direction=0
